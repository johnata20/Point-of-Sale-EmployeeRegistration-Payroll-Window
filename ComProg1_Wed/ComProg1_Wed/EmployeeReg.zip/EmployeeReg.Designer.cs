﻿namespace ComProg1_Wed
{
    partial class EmployeeReg
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.PersonInfoGrpBox = new System.Windows.Forms.GroupBox();
            this.ZipTxtBox = new System.Windows.Forms.TextBox();
            this.ZipLbl = new System.Windows.Forms.Label();
            this.StateLbl = new System.Windows.Forms.Label();
            this.CountryLbl = new System.Windows.Forms.Label();
            this.CityLbl = new System.Windows.Forms.Label();
            this.MuniLbl = new System.Windows.Forms.Label();
            this.BarangayLbl = new System.Windows.Forms.Label();
            this.StreetLbl = new System.Windows.Forms.Label();
            this.PhaseLbl = new System.Windows.Forms.Label();
            this.SubdiviLbl = new System.Windows.Forms.Label();
            this.HouseNumLbl = new System.Windows.Forms.Label();
            this.AddressLbl = new System.Windows.Forms.Label();
            this.WeightLbl = new System.Windows.Forms.Label();
            this.HeightLbl = new System.Windows.Forms.Label();
            this.StatusLbl = new System.Windows.Forms.Label();
            this.MuniTxtBox = new System.Windows.Forms.TextBox();
            this.CityTxtBox = new System.Windows.Forms.TextBox();
            this.CountryTxtBox = new System.Windows.Forms.TextBox();
            this.YearsLbl = new System.Windows.Forms.Label();
            this.StateTxtBox = new System.Windows.Forms.TextBox();
            this.BarangayTxtBox = new System.Windows.Forms.TextBox();
            this.StreetTxtBox = new System.Windows.Forms.TextBox();
            this.PhaseTxtBox = new System.Windows.Forms.TextBox();
            this.SubdiviTxtBox = new System.Windows.Forms.TextBox();
            this.HouseNumTxtBox = new System.Windows.Forms.TextBox();
            this.YearsTxtBox = new System.Windows.Forms.TextBox();
            this.WeightTxtBox = new System.Windows.Forms.TextBox();
            this.HeightTxtBox = new System.Windows.Forms.TextBox();
            this.StatusCmbBox = new System.Windows.Forms.ComboBox();
            this.PhilHealthTxtBox = new System.Windows.Forms.TextBox();
            this.PagibigTxtBox = new System.Windows.Forms.TextBox();
            this.TINTxtBox = new System.Windows.Forms.TextBox();
            this.SSSTxtBox = new System.Windows.Forms.TextBox();
            this.GenderCmbBox = new System.Windows.Forms.ComboBox();
            this.AgeCmbBox = new System.Windows.Forms.ComboBox();
            this.NumOfDepTxtBox = new System.Windows.Forms.TextBox();
            this.SNameTxtBox = new System.Windows.Forms.TextBox();
            this.MNameTxtBox = new System.Windows.Forms.TextBox();
            this.FNameTxtBox = new System.Windows.Forms.TextBox();
            this.SearchBtn = new System.Windows.Forms.Button();
            this.EmpNumTxtBox = new System.Windows.Forms.TextBox();
            this.PagibigLbl = new System.Windows.Forms.Label();
            this.PhilHealthLbl = new System.Windows.Forms.Label();
            this.GenderLbl = new System.Windows.Forms.Label();
            this.SSSLbl = new System.Windows.Forms.Label();
            this.TINLbl = new System.Windows.Forms.Label();
            this.AgeLbl = new System.Windows.Forms.Label();
            this.NumOfDepLbl = new System.Windows.Forms.Label();
            this.SNameLbl = new System.Windows.Forms.Label();
            this.MNameLbl = new System.Windows.Forms.Label();
            this.FNameLbl = new System.Windows.Forms.Label();
            this.EmpNumLbl = new System.Windows.Forms.Label();
            this.PersonInfoGrpBox2 = new System.Windows.Forms.GroupBox();
            this.ContactAddLbl = new System.Windows.Forms.Label();
            this.ContactNumLbl = new System.Windows.Forms.Label();
            this.ContactPerLbl = new System.Windows.Forms.Label();
            this.EmailLbl = new System.Windows.Forms.Label();
            this.Cell2Lbl = new System.Windows.Forms.Label();
            this.Cell1Lbl = new System.Windows.Forms.Label();
            this.TeleLbl = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.ContactAddTxtBox = new System.Windows.Forms.TextBox();
            this.ContactNumTxtBox = new System.Windows.Forms.TextBox();
            this.ContactPerTxtBox = new System.Windows.Forms.TextBox();
            this.EmailTxtBox = new System.Windows.Forms.TextBox();
            this.Cell2TxtBox = new System.Windows.Forms.TextBox();
            this.Cell1TxtBox = new System.Windows.Forms.TextBox();
            this.TeleTxtBox = new System.Windows.Forms.TextBox();
            this.PermZipTxtBox = new System.Windows.Forms.TextBox();
            this.PermZipLbl = new System.Windows.Forms.Label();
            this.PermStateLbl = new System.Windows.Forms.Label();
            this.PermCountryLbl = new System.Windows.Forms.Label();
            this.PermCityLbl = new System.Windows.Forms.Label();
            this.PermMuniLbl = new System.Windows.Forms.Label();
            this.PermBarangayLbl = new System.Windows.Forms.Label();
            this.PermStreetLbl = new System.Windows.Forms.Label();
            this.PermPhaseLbl = new System.Windows.Forms.Label();
            this.PermSubdiviLbl = new System.Windows.Forms.Label();
            this.PermHouseNumLbl = new System.Windows.Forms.Label();
            this.PermMuniTxtBox = new System.Windows.Forms.TextBox();
            this.PermCityTxtBox = new System.Windows.Forms.TextBox();
            this.PermCountryTxtBox = new System.Windows.Forms.TextBox();
            this.PermYearsLbl = new System.Windows.Forms.Label();
            this.PermStateTxtBox = new System.Windows.Forms.TextBox();
            this.PermBarangayTxtBox = new System.Windows.Forms.TextBox();
            this.PermStreetTxtBox = new System.Windows.Forms.TextBox();
            this.PermPhaseTxtBox = new System.Windows.Forms.TextBox();
            this.PermSubdiviTxtBox = new System.Windows.Forms.TextBox();
            this.PermHouseNumTxtBox = new System.Windows.Forms.TextBox();
            this.PermYearsTxtBox = new System.Windows.Forms.TextBox();
            this.EducationGrpBox = new System.Windows.Forms.GroupBox();
            this.SecondAddLbl = new System.Windows.Forms.Label();
            this.SecondSchoolLbl = new System.Windows.Forms.Label();
            this.ElemAwardLbl = new System.Windows.Forms.Label();
            this.ElemGradYearLbl = new System.Windows.Forms.Label();
            this.ElemAddLbl = new System.Windows.Forms.Label();
            this.ElemSchoolLbl = new System.Windows.Forms.Label();
            this.SecondAddTxtBox = new System.Windows.Forms.TextBox();
            this.ElemAwardTxtBox = new System.Windows.Forms.TextBox();
            this.SecondSchoolTxtBox = new System.Windows.Forms.TextBox();
            this.ElemGradYearDateTime = new System.Windows.Forms.DateTimePicker();
            this.ElemAddTxtBox = new System.Windows.Forms.TextBox();
            this.ElemSchoolTxtBox = new System.Windows.Forms.TextBox();
            this.EducationGrpBox2 = new System.Windows.Forms.GroupBox();
            this.OthersLbl = new System.Windows.Forms.Label();
            this.TertCourseLbl = new System.Windows.Forms.Label();
            this.GradAwardLbl = new System.Windows.Forms.Label();
            this.GradGradYearLbl = new System.Windows.Forms.Label();
            this.OthersTxtBox = new System.Windows.Forms.TextBox();
            this.GradGradYearDateTime = new System.Windows.Forms.DateTimePicker();
            this.GradAwardTxtBox = new System.Windows.Forms.TextBox();
            this.GradAddLbl = new System.Windows.Forms.Label();
            this.GradDegLbl = new System.Windows.Forms.Label();
            this.GradAddTxtBox = new System.Windows.Forms.TextBox();
            this.GradDegTxtBox = new System.Windows.Forms.TextBox();
            this.GradSchoolLbl = new System.Windows.Forms.Label();
            this.GradSchoolTxtBox = new System.Windows.Forms.TextBox();
            this.TertAwardLbl = new System.Windows.Forms.Label();
            this.TertGradYearLbl = new System.Windows.Forms.Label();
            this.TertAwardTxtBox = new System.Windows.Forms.TextBox();
            this.TertGradYearDateTime = new System.Windows.Forms.DateTimePicker();
            this.TertCourseTxtBox = new System.Windows.Forms.TextBox();
            this.TertAddLbl = new System.Windows.Forms.Label();
            this.TertSchoolLbl = new System.Windows.Forms.Label();
            this.TertAddTxtBox = new System.Windows.Forms.TextBox();
            this.TertSchoolTxtBox = new System.Windows.Forms.TextBox();
            this.SecondAwardLbl = new System.Windows.Forms.Label();
            this.SecondGradYearLbl = new System.Windows.Forms.Label();
            this.SecondAwardTxtBox = new System.Windows.Forms.TextBox();
            this.SecondGradYearDateTime = new System.Windows.Forms.DateTimePicker();
            this.AddBtn = new System.Windows.Forms.Button();
            this.NewBtn = new System.Windows.Forms.Button();
            this.ExitBtn = new System.Windows.Forms.Button();
            this.EditBtn = new System.Windows.Forms.Button();
            this.DeleteBtn = new System.Windows.Forms.Button();
            this.CancelBtn = new System.Windows.Forms.Button();
            this.DataGridGrpBox = new System.Windows.Forms.GroupBox();
            this.EmpDataGrid = new System.Windows.Forms.DataGridView();
            this.PositionGrpBox = new System.Windows.Forms.GroupBox();
            this.PicPathTxtBox = new System.Windows.Forms.TextBox();
            this.DeptLbl = new System.Windows.Forms.Label();
            this.HireLbl = new System.Windows.Forms.Label();
            this.DeptTxtBox = new System.Windows.Forms.TextBox();
            this.HireDateTime = new System.Windows.Forms.DateTimePicker();
            this.DependLbl = new System.Windows.Forms.Label();
            this.PosLbl = new System.Windows.Forms.Label();
            this.DependTxtBox = new System.Windows.Forms.TextBox();
            this.PosTxtBox = new System.Windows.Forms.TextBox();
            this.PicGrpBox = new System.Windows.Forms.GroupBox();
            this.BrowseBtn = new System.Windows.Forms.Button();
            this.EmpPicBox = new System.Windows.Forms.PictureBox();
            this.openFileDialog1 = new System.Windows.Forms.OpenFileDialog();
            this.PersonInfoGrpBox.SuspendLayout();
            this.PersonInfoGrpBox2.SuspendLayout();
            this.EducationGrpBox.SuspendLayout();
            this.EducationGrpBox2.SuspendLayout();
            this.DataGridGrpBox.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.EmpDataGrid)).BeginInit();
            this.PositionGrpBox.SuspendLayout();
            this.PicGrpBox.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.EmpPicBox)).BeginInit();
            this.SuspendLayout();
            // 
            // PersonInfoGrpBox
            // 
            this.PersonInfoGrpBox.Controls.Add(this.ZipTxtBox);
            this.PersonInfoGrpBox.Controls.Add(this.ZipLbl);
            this.PersonInfoGrpBox.Controls.Add(this.StateLbl);
            this.PersonInfoGrpBox.Controls.Add(this.CountryLbl);
            this.PersonInfoGrpBox.Controls.Add(this.CityLbl);
            this.PersonInfoGrpBox.Controls.Add(this.MuniLbl);
            this.PersonInfoGrpBox.Controls.Add(this.BarangayLbl);
            this.PersonInfoGrpBox.Controls.Add(this.StreetLbl);
            this.PersonInfoGrpBox.Controls.Add(this.PhaseLbl);
            this.PersonInfoGrpBox.Controls.Add(this.SubdiviLbl);
            this.PersonInfoGrpBox.Controls.Add(this.HouseNumLbl);
            this.PersonInfoGrpBox.Controls.Add(this.AddressLbl);
            this.PersonInfoGrpBox.Controls.Add(this.WeightLbl);
            this.PersonInfoGrpBox.Controls.Add(this.HeightLbl);
            this.PersonInfoGrpBox.Controls.Add(this.StatusLbl);
            this.PersonInfoGrpBox.Controls.Add(this.MuniTxtBox);
            this.PersonInfoGrpBox.Controls.Add(this.CityTxtBox);
            this.PersonInfoGrpBox.Controls.Add(this.CountryTxtBox);
            this.PersonInfoGrpBox.Controls.Add(this.YearsLbl);
            this.PersonInfoGrpBox.Controls.Add(this.StateTxtBox);
            this.PersonInfoGrpBox.Controls.Add(this.BarangayTxtBox);
            this.PersonInfoGrpBox.Controls.Add(this.StreetTxtBox);
            this.PersonInfoGrpBox.Controls.Add(this.PhaseTxtBox);
            this.PersonInfoGrpBox.Controls.Add(this.SubdiviTxtBox);
            this.PersonInfoGrpBox.Controls.Add(this.HouseNumTxtBox);
            this.PersonInfoGrpBox.Controls.Add(this.YearsTxtBox);
            this.PersonInfoGrpBox.Controls.Add(this.WeightTxtBox);
            this.PersonInfoGrpBox.Controls.Add(this.HeightTxtBox);
            this.PersonInfoGrpBox.Controls.Add(this.StatusCmbBox);
            this.PersonInfoGrpBox.Controls.Add(this.PhilHealthTxtBox);
            this.PersonInfoGrpBox.Controls.Add(this.PagibigTxtBox);
            this.PersonInfoGrpBox.Controls.Add(this.TINTxtBox);
            this.PersonInfoGrpBox.Controls.Add(this.SSSTxtBox);
            this.PersonInfoGrpBox.Controls.Add(this.GenderCmbBox);
            this.PersonInfoGrpBox.Controls.Add(this.AgeCmbBox);
            this.PersonInfoGrpBox.Controls.Add(this.NumOfDepTxtBox);
            this.PersonInfoGrpBox.Controls.Add(this.SNameTxtBox);
            this.PersonInfoGrpBox.Controls.Add(this.MNameTxtBox);
            this.PersonInfoGrpBox.Controls.Add(this.FNameTxtBox);
            this.PersonInfoGrpBox.Controls.Add(this.SearchBtn);
            this.PersonInfoGrpBox.Controls.Add(this.EmpNumTxtBox);
            this.PersonInfoGrpBox.Controls.Add(this.PagibigLbl);
            this.PersonInfoGrpBox.Controls.Add(this.PhilHealthLbl);
            this.PersonInfoGrpBox.Controls.Add(this.GenderLbl);
            this.PersonInfoGrpBox.Controls.Add(this.SSSLbl);
            this.PersonInfoGrpBox.Controls.Add(this.TINLbl);
            this.PersonInfoGrpBox.Controls.Add(this.AgeLbl);
            this.PersonInfoGrpBox.Controls.Add(this.NumOfDepLbl);
            this.PersonInfoGrpBox.Controls.Add(this.SNameLbl);
            this.PersonInfoGrpBox.Controls.Add(this.MNameLbl);
            this.PersonInfoGrpBox.Controls.Add(this.FNameLbl);
            this.PersonInfoGrpBox.Controls.Add(this.EmpNumLbl);
            this.PersonInfoGrpBox.Location = new System.Drawing.Point(13, 13);
            this.PersonInfoGrpBox.Name = "PersonInfoGrpBox";
            this.PersonInfoGrpBox.Size = new System.Drawing.Size(398, 687);
            this.PersonInfoGrpBox.TabIndex = 0;
            this.PersonInfoGrpBox.TabStop = false;
            this.PersonInfoGrpBox.Text = "Personal Information";
            // 
            // ZipTxtBox
            // 
            this.ZipTxtBox.Location = new System.Drawing.Point(163, 656);
            this.ZipTxtBox.Name = "ZipTxtBox";
            this.ZipTxtBox.Size = new System.Drawing.Size(137, 20);
            this.ZipTxtBox.TabIndex = 52;
            // 
            // ZipLbl
            // 
            this.ZipLbl.AutoSize = true;
            this.ZipLbl.Location = new System.Drawing.Point(39, 659);
            this.ZipLbl.Name = "ZipLbl";
            this.ZipLbl.Size = new System.Drawing.Size(50, 13);
            this.ZipLbl.TabIndex = 24;
            this.ZipLbl.Text = "Zip Code";
            // 
            // StateLbl
            // 
            this.StateLbl.AutoSize = true;
            this.StateLbl.Location = new System.Drawing.Point(38, 633);
            this.StateLbl.Name = "StateLbl";
            this.StateLbl.Size = new System.Drawing.Size(85, 13);
            this.StateLbl.TabIndex = 23;
            this.StateLbl.Text = "State / Province";
            // 
            // CountryLbl
            // 
            this.CountryLbl.AutoSize = true;
            this.CountryLbl.Location = new System.Drawing.Point(39, 607);
            this.CountryLbl.Name = "CountryLbl";
            this.CountryLbl.Size = new System.Drawing.Size(43, 13);
            this.CountryLbl.TabIndex = 22;
            this.CountryLbl.Text = "Country";
            // 
            // CityLbl
            // 
            this.CityLbl.AutoSize = true;
            this.CityLbl.Location = new System.Drawing.Point(38, 582);
            this.CityLbl.Name = "CityLbl";
            this.CityLbl.Size = new System.Drawing.Size(24, 13);
            this.CityLbl.TabIndex = 20;
            this.CityLbl.Text = "City";
            // 
            // MuniLbl
            // 
            this.MuniLbl.AutoSize = true;
            this.MuniLbl.Location = new System.Drawing.Point(39, 556);
            this.MuniLbl.Name = "MuniLbl";
            this.MuniLbl.Size = new System.Drawing.Size(62, 13);
            this.MuniLbl.TabIndex = 19;
            this.MuniLbl.Text = "Municipality";
            // 
            // BarangayLbl
            // 
            this.BarangayLbl.AutoSize = true;
            this.BarangayLbl.Location = new System.Drawing.Point(38, 530);
            this.BarangayLbl.Name = "BarangayLbl";
            this.BarangayLbl.Size = new System.Drawing.Size(52, 13);
            this.BarangayLbl.TabIndex = 19;
            this.BarangayLbl.Text = "Barangay";
            // 
            // StreetLbl
            // 
            this.StreetLbl.AutoSize = true;
            this.StreetLbl.Location = new System.Drawing.Point(39, 504);
            this.StreetLbl.Name = "StreetLbl";
            this.StreetLbl.Size = new System.Drawing.Size(35, 13);
            this.StreetLbl.TabIndex = 18;
            this.StreetLbl.Text = "Street";
            // 
            // PhaseLbl
            // 
            this.PhaseLbl.AutoSize = true;
            this.PhaseLbl.Location = new System.Drawing.Point(39, 479);
            this.PhaseLbl.Name = "PhaseLbl";
            this.PhaseLbl.Size = new System.Drawing.Size(77, 13);
            this.PhaseLbl.TabIndex = 17;
            this.PhaseLbl.Text = "Phase Number";
            // 
            // SubdiviLbl
            // 
            this.SubdiviLbl.AutoSize = true;
            this.SubdiviLbl.Location = new System.Drawing.Point(38, 455);
            this.SubdiviLbl.Name = "SubdiviLbl";
            this.SubdiviLbl.Size = new System.Drawing.Size(101, 13);
            this.SubdiviLbl.TabIndex = 16;
            this.SubdiviLbl.Text = "Subdivision Number";
            // 
            // HouseNumLbl
            // 
            this.HouseNumLbl.AutoSize = true;
            this.HouseNumLbl.Location = new System.Drawing.Point(39, 432);
            this.HouseNumLbl.Name = "HouseNumLbl";
            this.HouseNumLbl.Size = new System.Drawing.Size(78, 13);
            this.HouseNumLbl.TabIndex = 15;
            this.HouseNumLbl.Text = "House Number";
            // 
            // AddressLbl
            // 
            this.AddressLbl.AutoSize = true;
            this.AddressLbl.Location = new System.Drawing.Point(8, 391);
            this.AddressLbl.Name = "AddressLbl";
            this.AddressLbl.Size = new System.Drawing.Size(82, 13);
            this.AddressLbl.TabIndex = 14;
            this.AddressLbl.Text = "Current Address";
            // 
            // WeightLbl
            // 
            this.WeightLbl.AutoSize = true;
            this.WeightLbl.Location = new System.Drawing.Point(39, 372);
            this.WeightLbl.Name = "WeightLbl";
            this.WeightLbl.Size = new System.Drawing.Size(41, 13);
            this.WeightLbl.TabIndex = 13;
            this.WeightLbl.Text = "Weight";
            // 
            // HeightLbl
            // 
            this.HeightLbl.AutoSize = true;
            this.HeightLbl.Location = new System.Drawing.Point(38, 347);
            this.HeightLbl.Name = "HeightLbl";
            this.HeightLbl.Size = new System.Drawing.Size(38, 13);
            this.HeightLbl.TabIndex = 12;
            this.HeightLbl.Text = "Height";
            // 
            // StatusLbl
            // 
            this.StatusLbl.AutoSize = true;
            this.StatusLbl.Location = new System.Drawing.Point(39, 320);
            this.StatusLbl.Name = "StatusLbl";
            this.StatusLbl.Size = new System.Drawing.Size(37, 13);
            this.StatusLbl.TabIndex = 11;
            this.StatusLbl.Text = "Status";
            // 
            // MuniTxtBox
            // 
            this.MuniTxtBox.Location = new System.Drawing.Point(163, 553);
            this.MuniTxtBox.Name = "MuniTxtBox";
            this.MuniTxtBox.Size = new System.Drawing.Size(202, 20);
            this.MuniTxtBox.TabIndex = 51;
            // 
            // CityTxtBox
            // 
            this.CityTxtBox.Location = new System.Drawing.Point(163, 579);
            this.CityTxtBox.Name = "CityTxtBox";
            this.CityTxtBox.Size = new System.Drawing.Size(202, 20);
            this.CityTxtBox.TabIndex = 50;
            // 
            // CountryTxtBox
            // 
            this.CountryTxtBox.Location = new System.Drawing.Point(163, 604);
            this.CountryTxtBox.Name = "CountryTxtBox";
            this.CountryTxtBox.Size = new System.Drawing.Size(202, 20);
            this.CountryTxtBox.TabIndex = 49;
            // 
            // YearsLbl
            // 
            this.YearsLbl.AutoSize = true;
            this.YearsLbl.Location = new System.Drawing.Point(39, 411);
            this.YearsLbl.Name = "YearsLbl";
            this.YearsLbl.Size = new System.Drawing.Size(72, 13);
            this.YearsLbl.TabIndex = 21;
            this.YearsLbl.Text = "Years Of Stay";
            // 
            // StateTxtBox
            // 
            this.StateTxtBox.Location = new System.Drawing.Point(163, 630);
            this.StateTxtBox.Name = "StateTxtBox";
            this.StateTxtBox.Size = new System.Drawing.Size(202, 20);
            this.StateTxtBox.TabIndex = 48;
            // 
            // BarangayTxtBox
            // 
            this.BarangayTxtBox.Location = new System.Drawing.Point(163, 527);
            this.BarangayTxtBox.Name = "BarangayTxtBox";
            this.BarangayTxtBox.Size = new System.Drawing.Size(202, 20);
            this.BarangayTxtBox.TabIndex = 47;
            // 
            // StreetTxtBox
            // 
            this.StreetTxtBox.Location = new System.Drawing.Point(163, 501);
            this.StreetTxtBox.Name = "StreetTxtBox";
            this.StreetTxtBox.Size = new System.Drawing.Size(202, 20);
            this.StreetTxtBox.TabIndex = 46;
            // 
            // PhaseTxtBox
            // 
            this.PhaseTxtBox.Location = new System.Drawing.Point(163, 476);
            this.PhaseTxtBox.Name = "PhaseTxtBox";
            this.PhaseTxtBox.Size = new System.Drawing.Size(202, 20);
            this.PhaseTxtBox.TabIndex = 45;
            // 
            // SubdiviTxtBox
            // 
            this.SubdiviTxtBox.Location = new System.Drawing.Point(163, 452);
            this.SubdiviTxtBox.Name = "SubdiviTxtBox";
            this.SubdiviTxtBox.Size = new System.Drawing.Size(202, 20);
            this.SubdiviTxtBox.TabIndex = 44;
            // 
            // HouseNumTxtBox
            // 
            this.HouseNumTxtBox.Location = new System.Drawing.Point(163, 429);
            this.HouseNumTxtBox.Name = "HouseNumTxtBox";
            this.HouseNumTxtBox.Size = new System.Drawing.Size(114, 20);
            this.HouseNumTxtBox.TabIndex = 43;
            // 
            // YearsTxtBox
            // 
            this.YearsTxtBox.Location = new System.Drawing.Point(163, 406);
            this.YearsTxtBox.Name = "YearsTxtBox";
            this.YearsTxtBox.Size = new System.Drawing.Size(114, 20);
            this.YearsTxtBox.TabIndex = 42;
            // 
            // WeightTxtBox
            // 
            this.WeightTxtBox.Location = new System.Drawing.Point(163, 369);
            this.WeightTxtBox.Name = "WeightTxtBox";
            this.WeightTxtBox.Size = new System.Drawing.Size(114, 20);
            this.WeightTxtBox.TabIndex = 41;
            // 
            // HeightTxtBox
            // 
            this.HeightTxtBox.Location = new System.Drawing.Point(163, 344);
            this.HeightTxtBox.Name = "HeightTxtBox";
            this.HeightTxtBox.Size = new System.Drawing.Size(114, 20);
            this.HeightTxtBox.TabIndex = 40;
            // 
            // StatusCmbBox
            // 
            this.StatusCmbBox.FormattingEnabled = true;
            this.StatusCmbBox.Location = new System.Drawing.Point(163, 317);
            this.StatusCmbBox.Name = "StatusCmbBox";
            this.StatusCmbBox.Size = new System.Drawing.Size(114, 21);
            this.StatusCmbBox.TabIndex = 39;
            // 
            // PhilHealthTxtBox
            // 
            this.PhilHealthTxtBox.Location = new System.Drawing.Point(163, 265);
            this.PhilHealthTxtBox.Name = "PhilHealthTxtBox";
            this.PhilHealthTxtBox.Size = new System.Drawing.Size(202, 20);
            this.PhilHealthTxtBox.TabIndex = 38;
            // 
            // PagibigTxtBox
            // 
            this.PagibigTxtBox.Location = new System.Drawing.Point(163, 291);
            this.PagibigTxtBox.Name = "PagibigTxtBox";
            this.PagibigTxtBox.Size = new System.Drawing.Size(202, 20);
            this.PagibigTxtBox.TabIndex = 37;
            // 
            // TINTxtBox
            // 
            this.TINTxtBox.Location = new System.Drawing.Point(163, 239);
            this.TINTxtBox.Name = "TINTxtBox";
            this.TINTxtBox.Size = new System.Drawing.Size(202, 20);
            this.TINTxtBox.TabIndex = 36;
            // 
            // SSSTxtBox
            // 
            this.SSSTxtBox.Location = new System.Drawing.Point(163, 213);
            this.SSSTxtBox.Name = "SSSTxtBox";
            this.SSSTxtBox.Size = new System.Drawing.Size(202, 20);
            this.SSSTxtBox.TabIndex = 35;
            // 
            // GenderCmbBox
            // 
            this.GenderCmbBox.FormattingEnabled = true;
            this.GenderCmbBox.Location = new System.Drawing.Point(163, 186);
            this.GenderCmbBox.Name = "GenderCmbBox";
            this.GenderCmbBox.Size = new System.Drawing.Size(114, 21);
            this.GenderCmbBox.TabIndex = 34;
            // 
            // AgeCmbBox
            // 
            this.AgeCmbBox.FormattingEnabled = true;
            this.AgeCmbBox.Location = new System.Drawing.Point(163, 159);
            this.AgeCmbBox.Name = "AgeCmbBox";
            this.AgeCmbBox.Size = new System.Drawing.Size(114, 21);
            this.AgeCmbBox.TabIndex = 33;
            // 
            // NumOfDepTxtBox
            // 
            this.NumOfDepTxtBox.Location = new System.Drawing.Point(163, 132);
            this.NumOfDepTxtBox.Name = "NumOfDepTxtBox";
            this.NumOfDepTxtBox.Size = new System.Drawing.Size(202, 20);
            this.NumOfDepTxtBox.TabIndex = 32;
            // 
            // SNameTxtBox
            // 
            this.SNameTxtBox.Location = new System.Drawing.Point(163, 105);
            this.SNameTxtBox.Name = "SNameTxtBox";
            this.SNameTxtBox.Size = new System.Drawing.Size(202, 20);
            this.SNameTxtBox.TabIndex = 31;
            // 
            // MNameTxtBox
            // 
            this.MNameTxtBox.Location = new System.Drawing.Point(163, 79);
            this.MNameTxtBox.Name = "MNameTxtBox";
            this.MNameTxtBox.Size = new System.Drawing.Size(202, 20);
            this.MNameTxtBox.TabIndex = 30;
            // 
            // FNameTxtBox
            // 
            this.FNameTxtBox.Location = new System.Drawing.Point(163, 53);
            this.FNameTxtBox.Name = "FNameTxtBox";
            this.FNameTxtBox.Size = new System.Drawing.Size(202, 20);
            this.FNameTxtBox.TabIndex = 29;
            // 
            // SearchBtn
            // 
            this.SearchBtn.Location = new System.Drawing.Point(283, 21);
            this.SearchBtn.Name = "SearchBtn";
            this.SearchBtn.Size = new System.Drawing.Size(101, 23);
            this.SearchBtn.TabIndex = 28;
            this.SearchBtn.Text = "Search";
            this.SearchBtn.UseVisualStyleBackColor = true;
            this.SearchBtn.Click += new System.EventHandler(this.SearchBtn_Click);
            // 
            // EmpNumTxtBox
            // 
            this.EmpNumTxtBox.Location = new System.Drawing.Point(163, 22);
            this.EmpNumTxtBox.Name = "EmpNumTxtBox";
            this.EmpNumTxtBox.Size = new System.Drawing.Size(114, 20);
            this.EmpNumTxtBox.TabIndex = 27;
            // 
            // PagibigLbl
            // 
            this.PagibigLbl.AutoSize = true;
            this.PagibigLbl.Location = new System.Drawing.Point(39, 295);
            this.PagibigLbl.Name = "PagibigLbl";
            this.PagibigLbl.Size = new System.Drawing.Size(82, 13);
            this.PagibigLbl.TabIndex = 10;
            this.PagibigLbl.Text = "Pagibig Number";
            // 
            // PhilHealthLbl
            // 
            this.PhilHealthLbl.AutoSize = true;
            this.PhilHealthLbl.Location = new System.Drawing.Point(39, 268);
            this.PhilHealthLbl.Name = "PhilHealthLbl";
            this.PhilHealthLbl.Size = new System.Drawing.Size(95, 13);
            this.PhilHealthLbl.TabIndex = 9;
            this.PhilHealthLbl.Text = "PhilHealth Number";
            // 
            // GenderLbl
            // 
            this.GenderLbl.AutoSize = true;
            this.GenderLbl.Location = new System.Drawing.Point(38, 189);
            this.GenderLbl.Name = "GenderLbl";
            this.GenderLbl.Size = new System.Drawing.Size(42, 13);
            this.GenderLbl.TabIndex = 8;
            this.GenderLbl.Text = "Gender";
            // 
            // SSSLbl
            // 
            this.SSSLbl.AutoSize = true;
            this.SSSLbl.Location = new System.Drawing.Point(38, 216);
            this.SSSLbl.Name = "SSSLbl";
            this.SSSLbl.Size = new System.Drawing.Size(68, 13);
            this.SSSLbl.TabIndex = 7;
            this.SSSLbl.Text = "SSS Number";
            // 
            // TINLbl
            // 
            this.TINLbl.AutoSize = true;
            this.TINLbl.Location = new System.Drawing.Point(38, 242);
            this.TINLbl.Name = "TINLbl";
            this.TINLbl.Size = new System.Drawing.Size(65, 13);
            this.TINLbl.TabIndex = 6;
            this.TINLbl.Text = "TIN Number";
            // 
            // AgeLbl
            // 
            this.AgeLbl.AutoSize = true;
            this.AgeLbl.Location = new System.Drawing.Point(38, 162);
            this.AgeLbl.Name = "AgeLbl";
            this.AgeLbl.Size = new System.Drawing.Size(26, 13);
            this.AgeLbl.TabIndex = 5;
            this.AgeLbl.Text = "Age";
            // 
            // NumOfDepLbl
            // 
            this.NumOfDepLbl.AutoSize = true;
            this.NumOfDepLbl.Location = new System.Drawing.Point(38, 137);
            this.NumOfDepLbl.Name = "NumOfDepLbl";
            this.NumOfDepLbl.Size = new System.Drawing.Size(117, 13);
            this.NumOfDepLbl.TabIndex = 4;
            this.NumOfDepLbl.Text = "Number of Dependents";
            // 
            // SNameLbl
            // 
            this.SNameLbl.AutoSize = true;
            this.SNameLbl.Location = new System.Drawing.Point(38, 108);
            this.SNameLbl.Name = "SNameLbl";
            this.SNameLbl.Size = new System.Drawing.Size(49, 13);
            this.SNameLbl.TabIndex = 3;
            this.SNameLbl.Text = "Surname";
            // 
            // MNameLbl
            // 
            this.MNameLbl.AutoSize = true;
            this.MNameLbl.Location = new System.Drawing.Point(38, 82);
            this.MNameLbl.Name = "MNameLbl";
            this.MNameLbl.Size = new System.Drawing.Size(69, 13);
            this.MNameLbl.TabIndex = 2;
            this.MNameLbl.Text = "Middle Name";
            // 
            // FNameLbl
            // 
            this.FNameLbl.AutoSize = true;
            this.FNameLbl.Location = new System.Drawing.Point(38, 56);
            this.FNameLbl.Name = "FNameLbl";
            this.FNameLbl.Size = new System.Drawing.Size(57, 13);
            this.FNameLbl.TabIndex = 1;
            this.FNameLbl.Text = "First Name";
            // 
            // EmpNumLbl
            // 
            this.EmpNumLbl.AutoSize = true;
            this.EmpNumLbl.Location = new System.Drawing.Point(38, 24);
            this.EmpNumLbl.Name = "EmpNumLbl";
            this.EmpNumLbl.Size = new System.Drawing.Size(93, 13);
            this.EmpNumLbl.TabIndex = 0;
            this.EmpNumLbl.Text = "Employee Number";
            // 
            // PersonInfoGrpBox2
            // 
            this.PersonInfoGrpBox2.Controls.Add(this.ContactAddLbl);
            this.PersonInfoGrpBox2.Controls.Add(this.ContactNumLbl);
            this.PersonInfoGrpBox2.Controls.Add(this.ContactPerLbl);
            this.PersonInfoGrpBox2.Controls.Add(this.EmailLbl);
            this.PersonInfoGrpBox2.Controls.Add(this.Cell2Lbl);
            this.PersonInfoGrpBox2.Controls.Add(this.Cell1Lbl);
            this.PersonInfoGrpBox2.Controls.Add(this.TeleLbl);
            this.PersonInfoGrpBox2.Controls.Add(this.label11);
            this.PersonInfoGrpBox2.Controls.Add(this.ContactAddTxtBox);
            this.PersonInfoGrpBox2.Controls.Add(this.ContactNumTxtBox);
            this.PersonInfoGrpBox2.Controls.Add(this.ContactPerTxtBox);
            this.PersonInfoGrpBox2.Controls.Add(this.EmailTxtBox);
            this.PersonInfoGrpBox2.Controls.Add(this.Cell2TxtBox);
            this.PersonInfoGrpBox2.Controls.Add(this.Cell1TxtBox);
            this.PersonInfoGrpBox2.Controls.Add(this.TeleTxtBox);
            this.PersonInfoGrpBox2.Controls.Add(this.PermZipTxtBox);
            this.PersonInfoGrpBox2.Controls.Add(this.PermZipLbl);
            this.PersonInfoGrpBox2.Controls.Add(this.PermStateLbl);
            this.PersonInfoGrpBox2.Controls.Add(this.PermCountryLbl);
            this.PersonInfoGrpBox2.Controls.Add(this.PermCityLbl);
            this.PersonInfoGrpBox2.Controls.Add(this.PermMuniLbl);
            this.PersonInfoGrpBox2.Controls.Add(this.PermBarangayLbl);
            this.PersonInfoGrpBox2.Controls.Add(this.PermStreetLbl);
            this.PersonInfoGrpBox2.Controls.Add(this.PermPhaseLbl);
            this.PersonInfoGrpBox2.Controls.Add(this.PermSubdiviLbl);
            this.PersonInfoGrpBox2.Controls.Add(this.PermHouseNumLbl);
            this.PersonInfoGrpBox2.Controls.Add(this.PermMuniTxtBox);
            this.PersonInfoGrpBox2.Controls.Add(this.PermCityTxtBox);
            this.PersonInfoGrpBox2.Controls.Add(this.PermCountryTxtBox);
            this.PersonInfoGrpBox2.Controls.Add(this.PermYearsLbl);
            this.PersonInfoGrpBox2.Controls.Add(this.PermStateTxtBox);
            this.PersonInfoGrpBox2.Controls.Add(this.PermBarangayTxtBox);
            this.PersonInfoGrpBox2.Controls.Add(this.PermStreetTxtBox);
            this.PersonInfoGrpBox2.Controls.Add(this.PermPhaseTxtBox);
            this.PersonInfoGrpBox2.Controls.Add(this.PermSubdiviTxtBox);
            this.PersonInfoGrpBox2.Controls.Add(this.PermHouseNumTxtBox);
            this.PersonInfoGrpBox2.Controls.Add(this.PermYearsTxtBox);
            this.PersonInfoGrpBox2.Location = new System.Drawing.Point(417, 12);
            this.PersonInfoGrpBox2.Name = "PersonInfoGrpBox2";
            this.PersonInfoGrpBox2.Size = new System.Drawing.Size(358, 486);
            this.PersonInfoGrpBox2.TabIndex = 1;
            this.PersonInfoGrpBox2.TabStop = false;
            // 
            // ContactAddLbl
            // 
            this.ContactAddLbl.AutoSize = true;
            this.ContactAddLbl.Location = new System.Drawing.Point(15, 447);
            this.ContactAddLbl.Name = "ContactAddLbl";
            this.ContactAddLbl.Size = new System.Drawing.Size(121, 13);
            this.ContactAddLbl.TabIndex = 90;
            this.ContactAddLbl.Text = "Contact Person Address";
            // 
            // ContactNumLbl
            // 
            this.ContactNumLbl.AutoSize = true;
            this.ContactNumLbl.Location = new System.Drawing.Point(15, 423);
            this.ContactNumLbl.Name = "ContactNumLbl";
            this.ContactNumLbl.Size = new System.Drawing.Size(120, 13);
            this.ContactNumLbl.TabIndex = 89;
            this.ContactNumLbl.Text = "Contact Person Number";
            // 
            // ContactPerLbl
            // 
            this.ContactPerLbl.AutoSize = true;
            this.ContactPerLbl.Location = new System.Drawing.Point(15, 397);
            this.ContactPerLbl.Name = "ContactPerLbl";
            this.ContactPerLbl.Size = new System.Drawing.Size(80, 13);
            this.ContactPerLbl.TabIndex = 88;
            this.ContactPerLbl.Text = "Contact Person";
            // 
            // EmailLbl
            // 
            this.EmailLbl.AutoSize = true;
            this.EmailLbl.Location = new System.Drawing.Point(15, 375);
            this.EmailLbl.Name = "EmailLbl";
            this.EmailLbl.Size = new System.Drawing.Size(73, 13);
            this.EmailLbl.TabIndex = 87;
            this.EmailLbl.Text = "Email Address";
            // 
            // Cell2Lbl
            // 
            this.Cell2Lbl.AutoSize = true;
            this.Cell2Lbl.Location = new System.Drawing.Point(15, 351);
            this.Cell2Lbl.Name = "Cell2Lbl";
            this.Cell2Lbl.Size = new System.Drawing.Size(106, 13);
            this.Cell2Lbl.TabIndex = 86;
            this.Cell2Lbl.Text = "Cellphone Number(2)";
            // 
            // Cell1Lbl
            // 
            this.Cell1Lbl.AutoSize = true;
            this.Cell1Lbl.Location = new System.Drawing.Point(15, 327);
            this.Cell1Lbl.Name = "Cell1Lbl";
            this.Cell1Lbl.Size = new System.Drawing.Size(106, 13);
            this.Cell1Lbl.TabIndex = 85;
            this.Cell1Lbl.Text = "Cellphone Number(1)";
            // 
            // TeleLbl
            // 
            this.TeleLbl.AutoSize = true;
            this.TeleLbl.Location = new System.Drawing.Point(15, 303);
            this.TeleLbl.Name = "TeleLbl";
            this.TeleLbl.Size = new System.Drawing.Size(98, 13);
            this.TeleLbl.TabIndex = 84;
            this.TeleLbl.Text = "Telephone Number";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(9, 22);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(99, 13);
            this.label11.TabIndex = 83;
            this.label11.Text = "Permanent Address";
            // 
            // ContactAddTxtBox
            // 
            this.ContactAddTxtBox.Location = new System.Drawing.Point(140, 444);
            this.ContactAddTxtBox.Multiline = true;
            this.ContactAddTxtBox.Name = "ContactAddTxtBox";
            this.ContactAddTxtBox.Size = new System.Drawing.Size(202, 35);
            this.ContactAddTxtBox.TabIndex = 82;
            // 
            // ContactNumTxtBox
            // 
            this.ContactNumTxtBox.Location = new System.Drawing.Point(140, 420);
            this.ContactNumTxtBox.Name = "ContactNumTxtBox";
            this.ContactNumTxtBox.Size = new System.Drawing.Size(202, 20);
            this.ContactNumTxtBox.TabIndex = 81;
            // 
            // ContactPerTxtBox
            // 
            this.ContactPerTxtBox.Location = new System.Drawing.Point(140, 396);
            this.ContactPerTxtBox.Name = "ContactPerTxtBox";
            this.ContactPerTxtBox.Size = new System.Drawing.Size(202, 20);
            this.ContactPerTxtBox.TabIndex = 80;
            // 
            // EmailTxtBox
            // 
            this.EmailTxtBox.Location = new System.Drawing.Point(140, 372);
            this.EmailTxtBox.Name = "EmailTxtBox";
            this.EmailTxtBox.Size = new System.Drawing.Size(202, 20);
            this.EmailTxtBox.TabIndex = 79;
            // 
            // Cell2TxtBox
            // 
            this.Cell2TxtBox.Location = new System.Drawing.Point(140, 348);
            this.Cell2TxtBox.Name = "Cell2TxtBox";
            this.Cell2TxtBox.Size = new System.Drawing.Size(202, 20);
            this.Cell2TxtBox.TabIndex = 78;
            // 
            // Cell1TxtBox
            // 
            this.Cell1TxtBox.Location = new System.Drawing.Point(140, 324);
            this.Cell1TxtBox.Name = "Cell1TxtBox";
            this.Cell1TxtBox.Size = new System.Drawing.Size(202, 20);
            this.Cell1TxtBox.TabIndex = 77;
            // 
            // TeleTxtBox
            // 
            this.TeleTxtBox.Location = new System.Drawing.Point(140, 300);
            this.TeleTxtBox.Name = "TeleTxtBox";
            this.TeleTxtBox.Size = new System.Drawing.Size(202, 20);
            this.TeleTxtBox.TabIndex = 76;
            // 
            // PermZipTxtBox
            // 
            this.PermZipTxtBox.Location = new System.Drawing.Point(140, 274);
            this.PermZipTxtBox.Name = "PermZipTxtBox";
            this.PermZipTxtBox.Size = new System.Drawing.Size(137, 20);
            this.PermZipTxtBox.TabIndex = 75;
            // 
            // PermZipLbl
            // 
            this.PermZipLbl.AutoSize = true;
            this.PermZipLbl.Location = new System.Drawing.Point(16, 275);
            this.PermZipLbl.Name = "PermZipLbl";
            this.PermZipLbl.Size = new System.Drawing.Size(50, 13);
            this.PermZipLbl.TabIndex = 64;
            this.PermZipLbl.Text = "Zip Code";
            // 
            // PermStateLbl
            // 
            this.PermStateLbl.AutoSize = true;
            this.PermStateLbl.Location = new System.Drawing.Point(15, 250);
            this.PermStateLbl.Name = "PermStateLbl";
            this.PermStateLbl.Size = new System.Drawing.Size(85, 13);
            this.PermStateLbl.TabIndex = 63;
            this.PermStateLbl.Text = "State / Province";
            // 
            // PermCountryLbl
            // 
            this.PermCountryLbl.AutoSize = true;
            this.PermCountryLbl.Location = new System.Drawing.Point(15, 228);
            this.PermCountryLbl.Name = "PermCountryLbl";
            this.PermCountryLbl.Size = new System.Drawing.Size(43, 13);
            this.PermCountryLbl.TabIndex = 62;
            this.PermCountryLbl.Text = "Country";
            // 
            // PermCityLbl
            // 
            this.PermCityLbl.AutoSize = true;
            this.PermCityLbl.Location = new System.Drawing.Point(16, 203);
            this.PermCityLbl.Name = "PermCityLbl";
            this.PermCityLbl.Size = new System.Drawing.Size(24, 13);
            this.PermCityLbl.TabIndex = 60;
            this.PermCityLbl.Text = "City";
            // 
            // PermMuniLbl
            // 
            this.PermMuniLbl.AutoSize = true;
            this.PermMuniLbl.Location = new System.Drawing.Point(15, 179);
            this.PermMuniLbl.Name = "PermMuniLbl";
            this.PermMuniLbl.Size = new System.Drawing.Size(62, 13);
            this.PermMuniLbl.TabIndex = 58;
            this.PermMuniLbl.Text = "Municipality";
            // 
            // PermBarangayLbl
            // 
            this.PermBarangayLbl.AutoSize = true;
            this.PermBarangayLbl.Location = new System.Drawing.Point(15, 158);
            this.PermBarangayLbl.Name = "PermBarangayLbl";
            this.PermBarangayLbl.Size = new System.Drawing.Size(52, 13);
            this.PermBarangayLbl.TabIndex = 59;
            this.PermBarangayLbl.Text = "Barangay";
            // 
            // PermStreetLbl
            // 
            this.PermStreetLbl.AutoSize = true;
            this.PermStreetLbl.Location = new System.Drawing.Point(16, 137);
            this.PermStreetLbl.Name = "PermStreetLbl";
            this.PermStreetLbl.Size = new System.Drawing.Size(35, 13);
            this.PermStreetLbl.TabIndex = 57;
            this.PermStreetLbl.Text = "Street";
            // 
            // PermPhaseLbl
            // 
            this.PermPhaseLbl.AutoSize = true;
            this.PermPhaseLbl.Location = new System.Drawing.Point(16, 112);
            this.PermPhaseLbl.Name = "PermPhaseLbl";
            this.PermPhaseLbl.Size = new System.Drawing.Size(77, 13);
            this.PermPhaseLbl.TabIndex = 56;
            this.PermPhaseLbl.Text = "Phase Number";
            // 
            // PermSubdiviLbl
            // 
            this.PermSubdiviLbl.AutoSize = true;
            this.PermSubdiviLbl.Location = new System.Drawing.Point(15, 88);
            this.PermSubdiviLbl.Name = "PermSubdiviLbl";
            this.PermSubdiviLbl.Size = new System.Drawing.Size(101, 13);
            this.PermSubdiviLbl.TabIndex = 55;
            this.PermSubdiviLbl.Text = "Subdivision Number";
            // 
            // PermHouseNumLbl
            // 
            this.PermHouseNumLbl.AutoSize = true;
            this.PermHouseNumLbl.Location = new System.Drawing.Point(16, 64);
            this.PermHouseNumLbl.Name = "PermHouseNumLbl";
            this.PermHouseNumLbl.Size = new System.Drawing.Size(78, 13);
            this.PermHouseNumLbl.TabIndex = 54;
            this.PermHouseNumLbl.Text = "House Number";
            // 
            // PermMuniTxtBox
            // 
            this.PermMuniTxtBox.Location = new System.Drawing.Point(140, 177);
            this.PermMuniTxtBox.Name = "PermMuniTxtBox";
            this.PermMuniTxtBox.Size = new System.Drawing.Size(202, 20);
            this.PermMuniTxtBox.TabIndex = 74;
            // 
            // PermCityTxtBox
            // 
            this.PermCityTxtBox.Location = new System.Drawing.Point(140, 201);
            this.PermCityTxtBox.Name = "PermCityTxtBox";
            this.PermCityTxtBox.Size = new System.Drawing.Size(202, 20);
            this.PermCityTxtBox.TabIndex = 73;
            // 
            // PermCountryTxtBox
            // 
            this.PermCountryTxtBox.Location = new System.Drawing.Point(140, 225);
            this.PermCountryTxtBox.Name = "PermCountryTxtBox";
            this.PermCountryTxtBox.Size = new System.Drawing.Size(202, 20);
            this.PermCountryTxtBox.TabIndex = 72;
            // 
            // PermYearsLbl
            // 
            this.PermYearsLbl.AutoSize = true;
            this.PermYearsLbl.Location = new System.Drawing.Point(16, 44);
            this.PermYearsLbl.Name = "PermYearsLbl";
            this.PermYearsLbl.Size = new System.Drawing.Size(72, 13);
            this.PermYearsLbl.TabIndex = 61;
            this.PermYearsLbl.Text = "Years Of Stay";
            // 
            // PermStateTxtBox
            // 
            this.PermStateTxtBox.Location = new System.Drawing.Point(140, 249);
            this.PermStateTxtBox.Name = "PermStateTxtBox";
            this.PermStateTxtBox.Size = new System.Drawing.Size(202, 20);
            this.PermStateTxtBox.TabIndex = 71;
            // 
            // PermBarangayTxtBox
            // 
            this.PermBarangayTxtBox.Location = new System.Drawing.Point(140, 154);
            this.PermBarangayTxtBox.Name = "PermBarangayTxtBox";
            this.PermBarangayTxtBox.Size = new System.Drawing.Size(202, 20);
            this.PermBarangayTxtBox.TabIndex = 70;
            // 
            // PermStreetTxtBox
            // 
            this.PermStreetTxtBox.Location = new System.Drawing.Point(140, 131);
            this.PermStreetTxtBox.Name = "PermStreetTxtBox";
            this.PermStreetTxtBox.Size = new System.Drawing.Size(202, 20);
            this.PermStreetTxtBox.TabIndex = 69;
            // 
            // PermPhaseTxtBox
            // 
            this.PermPhaseTxtBox.Location = new System.Drawing.Point(140, 108);
            this.PermPhaseTxtBox.Name = "PermPhaseTxtBox";
            this.PermPhaseTxtBox.Size = new System.Drawing.Size(202, 20);
            this.PermPhaseTxtBox.TabIndex = 68;
            // 
            // PermSubdiviTxtBox
            // 
            this.PermSubdiviTxtBox.Location = new System.Drawing.Point(140, 85);
            this.PermSubdiviTxtBox.Name = "PermSubdiviTxtBox";
            this.PermSubdiviTxtBox.Size = new System.Drawing.Size(202, 20);
            this.PermSubdiviTxtBox.TabIndex = 67;
            // 
            // PermHouseNumTxtBox
            // 
            this.PermHouseNumTxtBox.Location = new System.Drawing.Point(140, 62);
            this.PermHouseNumTxtBox.Name = "PermHouseNumTxtBox";
            this.PermHouseNumTxtBox.Size = new System.Drawing.Size(114, 20);
            this.PermHouseNumTxtBox.TabIndex = 66;
            // 
            // PermYearsTxtBox
            // 
            this.PermYearsTxtBox.Location = new System.Drawing.Point(140, 39);
            this.PermYearsTxtBox.Name = "PermYearsTxtBox";
            this.PermYearsTxtBox.Size = new System.Drawing.Size(114, 20);
            this.PermYearsTxtBox.TabIndex = 65;
            // 
            // EducationGrpBox
            // 
            this.EducationGrpBox.Controls.Add(this.SecondAddLbl);
            this.EducationGrpBox.Controls.Add(this.SecondSchoolLbl);
            this.EducationGrpBox.Controls.Add(this.ElemAwardLbl);
            this.EducationGrpBox.Controls.Add(this.ElemGradYearLbl);
            this.EducationGrpBox.Controls.Add(this.ElemAddLbl);
            this.EducationGrpBox.Controls.Add(this.ElemSchoolLbl);
            this.EducationGrpBox.Controls.Add(this.SecondAddTxtBox);
            this.EducationGrpBox.Controls.Add(this.ElemAwardTxtBox);
            this.EducationGrpBox.Controls.Add(this.SecondSchoolTxtBox);
            this.EducationGrpBox.Controls.Add(this.ElemGradYearDateTime);
            this.EducationGrpBox.Controls.Add(this.ElemAddTxtBox);
            this.EducationGrpBox.Controls.Add(this.ElemSchoolTxtBox);
            this.EducationGrpBox.Location = new System.Drawing.Point(417, 504);
            this.EducationGrpBox.Name = "EducationGrpBox";
            this.EducationGrpBox.Size = new System.Drawing.Size(358, 196);
            this.EducationGrpBox.TabIndex = 2;
            this.EducationGrpBox.TabStop = false;
            this.EducationGrpBox.Text = "Educational Attainment";
            // 
            // SecondAddLbl
            // 
            this.SecondAddLbl.AutoSize = true;
            this.SecondAddLbl.Location = new System.Drawing.Point(15, 162);
            this.SecondAddLbl.Name = "SecondAddLbl";
            this.SecondAddLbl.Size = new System.Drawing.Size(45, 13);
            this.SecondAddLbl.TabIndex = 95;
            this.SecondAddLbl.Text = "Address";
            // 
            // SecondSchoolLbl
            // 
            this.SecondSchoolLbl.AutoSize = true;
            this.SecondSchoolLbl.Location = new System.Drawing.Point(15, 134);
            this.SecondSchoolLbl.Name = "SecondSchoolLbl";
            this.SecondSchoolLbl.Size = new System.Drawing.Size(94, 13);
            this.SecondSchoolLbl.TabIndex = 94;
            this.SecondSchoolLbl.Text = "Secondary School";
            // 
            // ElemAwardLbl
            // 
            this.ElemAwardLbl.AutoSize = true;
            this.ElemAwardLbl.Location = new System.Drawing.Point(15, 111);
            this.ElemAwardLbl.Name = "ElemAwardLbl";
            this.ElemAwardLbl.Size = new System.Drawing.Size(47, 13);
            this.ElemAwardLbl.TabIndex = 93;
            this.ElemAwardLbl.Text = "Award/s";
            // 
            // ElemGradYearLbl
            // 
            this.ElemGradYearLbl.AutoSize = true;
            this.ElemGradYearLbl.Location = new System.Drawing.Point(15, 86);
            this.ElemGradYearLbl.Name = "ElemGradYearLbl";
            this.ElemGradYearLbl.Size = new System.Drawing.Size(82, 13);
            this.ElemGradYearLbl.TabIndex = 92;
            this.ElemGradYearLbl.Text = "Year Graduated";
            // 
            // ElemAddLbl
            // 
            this.ElemAddLbl.AutoSize = true;
            this.ElemAddLbl.Location = new System.Drawing.Point(15, 54);
            this.ElemAddLbl.Name = "ElemAddLbl";
            this.ElemAddLbl.Size = new System.Drawing.Size(45, 13);
            this.ElemAddLbl.TabIndex = 91;
            this.ElemAddLbl.Text = "Address";
            // 
            // ElemSchoolLbl
            // 
            this.ElemSchoolLbl.AutoSize = true;
            this.ElemSchoolLbl.Location = new System.Drawing.Point(16, 23);
            this.ElemSchoolLbl.Name = "ElemSchoolLbl";
            this.ElemSchoolLbl.Size = new System.Drawing.Size(95, 13);
            this.ElemSchoolLbl.TabIndex = 90;
            this.ElemSchoolLbl.Text = "Elementary School";
            // 
            // SecondAddTxtBox
            // 
            this.SecondAddTxtBox.Location = new System.Drawing.Point(140, 155);
            this.SecondAddTxtBox.Multiline = true;
            this.SecondAddTxtBox.Name = "SecondAddTxtBox";
            this.SecondAddTxtBox.Size = new System.Drawing.Size(202, 30);
            this.SecondAddTxtBox.TabIndex = 87;
            // 
            // ElemAwardTxtBox
            // 
            this.ElemAwardTxtBox.Location = new System.Drawing.Point(140, 108);
            this.ElemAwardTxtBox.Name = "ElemAwardTxtBox";
            this.ElemAwardTxtBox.Size = new System.Drawing.Size(202, 20);
            this.ElemAwardTxtBox.TabIndex = 86;
            // 
            // SecondSchoolTxtBox
            // 
            this.SecondSchoolTxtBox.Location = new System.Drawing.Point(140, 131);
            this.SecondSchoolTxtBox.Name = "SecondSchoolTxtBox";
            this.SecondSchoolTxtBox.Size = new System.Drawing.Size(202, 20);
            this.SecondSchoolTxtBox.TabIndex = 85;
            // 
            // ElemGradYearDateTime
            // 
            this.ElemGradYearDateTime.CustomFormat = "";
            this.ElemGradYearDateTime.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.ElemGradYearDateTime.Location = new System.Drawing.Point(140, 84);
            this.ElemGradYearDateTime.Name = "ElemGradYearDateTime";
            this.ElemGradYearDateTime.Size = new System.Drawing.Size(202, 20);
            this.ElemGradYearDateTime.TabIndex = 84;
            // 
            // ElemAddTxtBox
            // 
            this.ElemAddTxtBox.Location = new System.Drawing.Point(140, 45);
            this.ElemAddTxtBox.Multiline = true;
            this.ElemAddTxtBox.Name = "ElemAddTxtBox";
            this.ElemAddTxtBox.Size = new System.Drawing.Size(202, 33);
            this.ElemAddTxtBox.TabIndex = 83;
            // 
            // ElemSchoolTxtBox
            // 
            this.ElemSchoolTxtBox.Location = new System.Drawing.Point(140, 19);
            this.ElemSchoolTxtBox.Name = "ElemSchoolTxtBox";
            this.ElemSchoolTxtBox.Size = new System.Drawing.Size(202, 20);
            this.ElemSchoolTxtBox.TabIndex = 82;
            // 
            // EducationGrpBox2
            // 
            this.EducationGrpBox2.Controls.Add(this.OthersLbl);
            this.EducationGrpBox2.Controls.Add(this.TertCourseLbl);
            this.EducationGrpBox2.Controls.Add(this.GradAwardLbl);
            this.EducationGrpBox2.Controls.Add(this.GradGradYearLbl);
            this.EducationGrpBox2.Controls.Add(this.OthersTxtBox);
            this.EducationGrpBox2.Controls.Add(this.GradGradYearDateTime);
            this.EducationGrpBox2.Controls.Add(this.GradAwardTxtBox);
            this.EducationGrpBox2.Controls.Add(this.GradAddLbl);
            this.EducationGrpBox2.Controls.Add(this.GradDegLbl);
            this.EducationGrpBox2.Controls.Add(this.GradAddTxtBox);
            this.EducationGrpBox2.Controls.Add(this.GradDegTxtBox);
            this.EducationGrpBox2.Controls.Add(this.GradSchoolLbl);
            this.EducationGrpBox2.Controls.Add(this.GradSchoolTxtBox);
            this.EducationGrpBox2.Controls.Add(this.TertAwardLbl);
            this.EducationGrpBox2.Controls.Add(this.TertGradYearLbl);
            this.EducationGrpBox2.Controls.Add(this.TertAwardTxtBox);
            this.EducationGrpBox2.Controls.Add(this.TertGradYearDateTime);
            this.EducationGrpBox2.Controls.Add(this.TertCourseTxtBox);
            this.EducationGrpBox2.Controls.Add(this.TertAddLbl);
            this.EducationGrpBox2.Controls.Add(this.TertSchoolLbl);
            this.EducationGrpBox2.Controls.Add(this.TertAddTxtBox);
            this.EducationGrpBox2.Controls.Add(this.TertSchoolTxtBox);
            this.EducationGrpBox2.Controls.Add(this.SecondAwardLbl);
            this.EducationGrpBox2.Controls.Add(this.SecondGradYearLbl);
            this.EducationGrpBox2.Controls.Add(this.SecondAwardTxtBox);
            this.EducationGrpBox2.Controls.Add(this.SecondGradYearDateTime);
            this.EducationGrpBox2.Location = new System.Drawing.Point(781, 13);
            this.EducationGrpBox2.Name = "EducationGrpBox2";
            this.EducationGrpBox2.Size = new System.Drawing.Size(557, 220);
            this.EducationGrpBox2.TabIndex = 3;
            this.EducationGrpBox2.TabStop = false;
            // 
            // OthersLbl
            // 
            this.OthersLbl.AutoSize = true;
            this.OthersLbl.Location = new System.Drawing.Point(298, 165);
            this.OthersLbl.Name = "OthersLbl";
            this.OthersLbl.Size = new System.Drawing.Size(38, 13);
            this.OthersLbl.TabIndex = 121;
            this.OthersLbl.Text = "Others";
            // 
            // TertCourseLbl
            // 
            this.TertCourseLbl.AutoSize = true;
            this.TertCourseLbl.Location = new System.Drawing.Point(18, 130);
            this.TertCourseLbl.Name = "TertCourseLbl";
            this.TertCourseLbl.Size = new System.Drawing.Size(40, 13);
            this.TertCourseLbl.TabIndex = 120;
            this.TertCourseLbl.Text = "Course";
            // 
            // GradAwardLbl
            // 
            this.GradAwardLbl.AutoSize = true;
            this.GradAwardLbl.Location = new System.Drawing.Point(298, 139);
            this.GradAwardLbl.Name = "GradAwardLbl";
            this.GradAwardLbl.Size = new System.Drawing.Size(47, 13);
            this.GradAwardLbl.TabIndex = 119;
            this.GradAwardLbl.Text = "Award/s";
            // 
            // GradGradYearLbl
            // 
            this.GradGradYearLbl.AutoSize = true;
            this.GradGradYearLbl.Location = new System.Drawing.Point(297, 114);
            this.GradGradYearLbl.Name = "GradGradYearLbl";
            this.GradGradYearLbl.Size = new System.Drawing.Size(82, 13);
            this.GradGradYearLbl.TabIndex = 118;
            this.GradGradYearLbl.Text = "Year Graduated";
            // 
            // OthersTxtBox
            // 
            this.OthersTxtBox.Location = new System.Drawing.Point(397, 162);
            this.OthersTxtBox.Name = "OthersTxtBox";
            this.OthersTxtBox.Size = new System.Drawing.Size(149, 20);
            this.OthersTxtBox.TabIndex = 117;
            // 
            // GradGradYearDateTime
            // 
            this.GradGradYearDateTime.CustomFormat = "";
            this.GradGradYearDateTime.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.GradGradYearDateTime.Location = new System.Drawing.Point(385, 114);
            this.GradGradYearDateTime.Name = "GradGradYearDateTime";
            this.GradGradYearDateTime.Size = new System.Drawing.Size(160, 20);
            this.GradGradYearDateTime.TabIndex = 116;
            // 
            // GradAwardTxtBox
            // 
            this.GradAwardTxtBox.Location = new System.Drawing.Point(397, 136);
            this.GradAwardTxtBox.Name = "GradAwardTxtBox";
            this.GradAwardTxtBox.Size = new System.Drawing.Size(149, 20);
            this.GradAwardTxtBox.TabIndex = 115;
            // 
            // GradAddLbl
            // 
            this.GradAddLbl.AutoSize = true;
            this.GradAddLbl.Location = new System.Drawing.Point(298, 52);
            this.GradAddLbl.Name = "GradAddLbl";
            this.GradAddLbl.Size = new System.Drawing.Size(45, 13);
            this.GradAddLbl.TabIndex = 114;
            this.GradAddLbl.Text = "Address";
            // 
            // GradDegLbl
            // 
            this.GradDegLbl.AutoSize = true;
            this.GradDegLbl.Location = new System.Drawing.Point(297, 86);
            this.GradDegLbl.Name = "GradDegLbl";
            this.GradDegLbl.Size = new System.Drawing.Size(42, 13);
            this.GradDegLbl.TabIndex = 113;
            this.GradDegLbl.Text = "Degree";
            // 
            // GradAddTxtBox
            // 
            this.GradAddTxtBox.Location = new System.Drawing.Point(397, 46);
            this.GradAddTxtBox.Multiline = true;
            this.GradAddTxtBox.Name = "GradAddTxtBox";
            this.GradAddTxtBox.Size = new System.Drawing.Size(149, 30);
            this.GradAddTxtBox.TabIndex = 112;
            // 
            // GradDegTxtBox
            // 
            this.GradDegTxtBox.Location = new System.Drawing.Point(398, 84);
            this.GradDegTxtBox.Name = "GradDegTxtBox";
            this.GradDegTxtBox.Size = new System.Drawing.Size(148, 20);
            this.GradDegTxtBox.TabIndex = 111;
            // 
            // GradSchoolLbl
            // 
            this.GradSchoolLbl.AutoSize = true;
            this.GradSchoolLbl.Location = new System.Drawing.Point(297, 24);
            this.GradSchoolLbl.Name = "GradSchoolLbl";
            this.GradSchoolLbl.Size = new System.Drawing.Size(87, 13);
            this.GradSchoolLbl.TabIndex = 109;
            this.GradSchoolLbl.Text = "Graduate School";
            // 
            // GradSchoolTxtBox
            // 
            this.GradSchoolTxtBox.Location = new System.Drawing.Point(397, 18);
            this.GradSchoolTxtBox.Name = "GradSchoolTxtBox";
            this.GradSchoolTxtBox.Size = new System.Drawing.Size(149, 20);
            this.GradSchoolTxtBox.TabIndex = 108;
            // 
            // TertAwardLbl
            // 
            this.TertAwardLbl.AutoSize = true;
            this.TertAwardLbl.Location = new System.Drawing.Point(18, 185);
            this.TertAwardLbl.Name = "TertAwardLbl";
            this.TertAwardLbl.Size = new System.Drawing.Size(47, 13);
            this.TertAwardLbl.TabIndex = 106;
            this.TertAwardLbl.Text = "Award/s";
            // 
            // TertGradYearLbl
            // 
            this.TertGradYearLbl.AutoSize = true;
            this.TertGradYearLbl.Location = new System.Drawing.Point(18, 160);
            this.TertGradYearLbl.Name = "TertGradYearLbl";
            this.TertGradYearLbl.Size = new System.Drawing.Size(82, 13);
            this.TertGradYearLbl.TabIndex = 105;
            this.TertGradYearLbl.Text = "Year Graduated";
            // 
            // TertAwardTxtBox
            // 
            this.TertAwardTxtBox.Location = new System.Drawing.Point(118, 183);
            this.TertAwardTxtBox.Name = "TertAwardTxtBox";
            this.TertAwardTxtBox.Size = new System.Drawing.Size(149, 20);
            this.TertAwardTxtBox.TabIndex = 104;
            // 
            // TertGradYearDateTime
            // 
            this.TertGradYearDateTime.CustomFormat = "";
            this.TertGradYearDateTime.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.TertGradYearDateTime.Location = new System.Drawing.Point(118, 159);
            this.TertGradYearDateTime.Name = "TertGradYearDateTime";
            this.TertGradYearDateTime.Size = new System.Drawing.Size(164, 20);
            this.TertGradYearDateTime.TabIndex = 103;
            // 
            // TertCourseTxtBox
            // 
            this.TertCourseTxtBox.Location = new System.Drawing.Point(118, 132);
            this.TertCourseTxtBox.Name = "TertCourseTxtBox";
            this.TertCourseTxtBox.Size = new System.Drawing.Size(149, 20);
            this.TertCourseTxtBox.TabIndex = 102;
            // 
            // TertAddLbl
            // 
            this.TertAddLbl.AutoSize = true;
            this.TertAddLbl.Location = new System.Drawing.Point(19, 101);
            this.TertAddLbl.Name = "TertAddLbl";
            this.TertAddLbl.Size = new System.Drawing.Size(45, 13);
            this.TertAddLbl.TabIndex = 101;
            this.TertAddLbl.Text = "Address";
            // 
            // TertSchoolLbl
            // 
            this.TertSchoolLbl.AutoSize = true;
            this.TertSchoolLbl.Location = new System.Drawing.Point(19, 73);
            this.TertSchoolLbl.Name = "TertSchoolLbl";
            this.TertSchoolLbl.Size = new System.Drawing.Size(78, 13);
            this.TertSchoolLbl.TabIndex = 100;
            this.TertSchoolLbl.Text = "Tertiary School";
            // 
            // TertAddTxtBox
            // 
            this.TertAddTxtBox.Location = new System.Drawing.Point(118, 95);
            this.TertAddTxtBox.Multiline = true;
            this.TertAddTxtBox.Name = "TertAddTxtBox";
            this.TertAddTxtBox.Size = new System.Drawing.Size(149, 30);
            this.TertAddTxtBox.TabIndex = 99;
            // 
            // TertSchoolTxtBox
            // 
            this.TertSchoolTxtBox.Location = new System.Drawing.Point(119, 70);
            this.TertSchoolTxtBox.Name = "TertSchoolTxtBox";
            this.TertSchoolTxtBox.Size = new System.Drawing.Size(148, 20);
            this.TertSchoolTxtBox.TabIndex = 98;
            // 
            // SecondAwardLbl
            // 
            this.SecondAwardLbl.AutoSize = true;
            this.SecondAwardLbl.Location = new System.Drawing.Point(18, 46);
            this.SecondAwardLbl.Name = "SecondAwardLbl";
            this.SecondAwardLbl.Size = new System.Drawing.Size(47, 13);
            this.SecondAwardLbl.TabIndex = 97;
            this.SecondAwardLbl.Text = "Award/s";
            // 
            // SecondGradYearLbl
            // 
            this.SecondGradYearLbl.AutoSize = true;
            this.SecondGradYearLbl.Location = new System.Drawing.Point(18, 21);
            this.SecondGradYearLbl.Name = "SecondGradYearLbl";
            this.SecondGradYearLbl.Size = new System.Drawing.Size(82, 13);
            this.SecondGradYearLbl.TabIndex = 96;
            this.SecondGradYearLbl.Text = "Year Graduated";
            // 
            // SecondAwardTxtBox
            // 
            this.SecondAwardTxtBox.Location = new System.Drawing.Point(118, 44);
            this.SecondAwardTxtBox.Name = "SecondAwardTxtBox";
            this.SecondAwardTxtBox.Size = new System.Drawing.Size(149, 20);
            this.SecondAwardTxtBox.TabIndex = 95;
            // 
            // SecondGradYearDateTime
            // 
            this.SecondGradYearDateTime.CustomFormat = "dd/MM/yyyy";
            this.SecondGradYearDateTime.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.SecondGradYearDateTime.Location = new System.Drawing.Point(118, 20);
            this.SecondGradYearDateTime.Name = "SecondGradYearDateTime";
            this.SecondGradYearDateTime.Size = new System.Drawing.Size(164, 20);
            this.SecondGradYearDateTime.TabIndex = 94;
            // 
            // AddBtn
            // 
            this.AddBtn.Location = new System.Drawing.Point(781, 646);
            this.AddBtn.Name = "AddBtn";
            this.AddBtn.Size = new System.Drawing.Size(86, 43);
            this.AddBtn.TabIndex = 4;
            this.AddBtn.Text = "Add";
            this.AddBtn.UseVisualStyleBackColor = true;
            this.AddBtn.Click += new System.EventHandler(this.AddBtn_Click);
            // 
            // NewBtn
            // 
            this.NewBtn.Location = new System.Drawing.Point(875, 646);
            this.NewBtn.Name = "NewBtn";
            this.NewBtn.Size = new System.Drawing.Size(86, 43);
            this.NewBtn.TabIndex = 5;
            this.NewBtn.Text = "New";
            this.NewBtn.UseVisualStyleBackColor = true;
            this.NewBtn.Click += new System.EventHandler(this.NewBtn_Click);
            // 
            // ExitBtn
            // 
            this.ExitBtn.Location = new System.Drawing.Point(968, 646);
            this.ExitBtn.Name = "ExitBtn";
            this.ExitBtn.Size = new System.Drawing.Size(86, 43);
            this.ExitBtn.TabIndex = 6;
            this.ExitBtn.Text = "Exit";
            this.ExitBtn.UseVisualStyleBackColor = true;
            this.ExitBtn.Click += new System.EventHandler(this.ExitBtn_Click);
            // 
            // EditBtn
            // 
            this.EditBtn.Location = new System.Drawing.Point(1062, 647);
            this.EditBtn.Name = "EditBtn";
            this.EditBtn.Size = new System.Drawing.Size(86, 43);
            this.EditBtn.TabIndex = 7;
            this.EditBtn.Text = "Edit";
            this.EditBtn.UseVisualStyleBackColor = true;
            this.EditBtn.Click += new System.EventHandler(this.EditBtn_Click);
            // 
            // DeleteBtn
            // 
            this.DeleteBtn.Location = new System.Drawing.Point(1158, 647);
            this.DeleteBtn.Name = "DeleteBtn";
            this.DeleteBtn.Size = new System.Drawing.Size(86, 43);
            this.DeleteBtn.TabIndex = 8;
            this.DeleteBtn.Text = "Delete";
            this.DeleteBtn.UseVisualStyleBackColor = true;
            this.DeleteBtn.Click += new System.EventHandler(this.DeleteBtn_Click);
            // 
            // CancelBtn
            // 
            this.CancelBtn.Location = new System.Drawing.Point(1254, 647);
            this.CancelBtn.Name = "CancelBtn";
            this.CancelBtn.Size = new System.Drawing.Size(84, 43);
            this.CancelBtn.TabIndex = 9;
            this.CancelBtn.Text = "Cancel";
            this.CancelBtn.UseVisualStyleBackColor = true;
            this.CancelBtn.Click += new System.EventHandler(this.CancelBtn_Click);
            // 
            // DataGridGrpBox
            // 
            this.DataGridGrpBox.Controls.Add(this.EmpDataGrid);
            this.DataGridGrpBox.Location = new System.Drawing.Point(781, 436);
            this.DataGridGrpBox.Name = "DataGridGrpBox";
            this.DataGridGrpBox.Size = new System.Drawing.Size(557, 205);
            this.DataGridGrpBox.TabIndex = 10;
            this.DataGridGrpBox.TabStop = false;
            // 
            // EmpDataGrid
            // 
            this.EmpDataGrid.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.EmpDataGrid.Location = new System.Drawing.Point(8, 14);
            this.EmpDataGrid.Name = "EmpDataGrid";
            this.EmpDataGrid.Size = new System.Drawing.Size(540, 182);
            this.EmpDataGrid.TabIndex = 0;
            // 
            // PositionGrpBox
            // 
            this.PositionGrpBox.Controls.Add(this.PicPathTxtBox);
            this.PositionGrpBox.Controls.Add(this.DeptLbl);
            this.PositionGrpBox.Controls.Add(this.HireLbl);
            this.PositionGrpBox.Controls.Add(this.DeptTxtBox);
            this.PositionGrpBox.Controls.Add(this.HireDateTime);
            this.PositionGrpBox.Controls.Add(this.DependLbl);
            this.PositionGrpBox.Controls.Add(this.PosLbl);
            this.PositionGrpBox.Controls.Add(this.DependTxtBox);
            this.PositionGrpBox.Controls.Add(this.PosTxtBox);
            this.PositionGrpBox.Location = new System.Drawing.Point(781, 240);
            this.PositionGrpBox.Name = "PositionGrpBox";
            this.PositionGrpBox.Size = new System.Drawing.Size(308, 197);
            this.PositionGrpBox.TabIndex = 11;
            this.PositionGrpBox.TabStop = false;
            // 
            // PicPathTxtBox
            // 
            this.PicPathTxtBox.Location = new System.Drawing.Point(22, 137);
            this.PicPathTxtBox.Name = "PicPathTxtBox";
            this.PicPathTxtBox.Size = new System.Drawing.Size(100, 20);
            this.PicPathTxtBox.TabIndex = 108;
            // 
            // DeptLbl
            // 
            this.DeptLbl.AutoSize = true;
            this.DeptLbl.Location = new System.Drawing.Point(19, 103);
            this.DeptLbl.Name = "DeptLbl";
            this.DeptLbl.Size = new System.Drawing.Size(62, 13);
            this.DeptLbl.TabIndex = 107;
            this.DeptLbl.Text = "Department";
            // 
            // HireLbl
            // 
            this.HireLbl.AutoSize = true;
            this.HireLbl.Location = new System.Drawing.Point(19, 76);
            this.HireLbl.Name = "HireLbl";
            this.HireLbl.Size = new System.Drawing.Size(58, 13);
            this.HireLbl.TabIndex = 106;
            this.HireLbl.Text = "Date Hired";
            // 
            // DeptTxtBox
            // 
            this.DeptTxtBox.Location = new System.Drawing.Point(117, 99);
            this.DeptTxtBox.Name = "DeptTxtBox";
            this.DeptTxtBox.Size = new System.Drawing.Size(165, 20);
            this.DeptTxtBox.TabIndex = 105;
            // 
            // HireDateTime
            // 
            this.HireDateTime.CustomFormat = "";
            this.HireDateTime.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.HireDateTime.Location = new System.Drawing.Point(119, 73);
            this.HireDateTime.Name = "HireDateTime";
            this.HireDateTime.Size = new System.Drawing.Size(164, 20);
            this.HireDateTime.TabIndex = 104;
            // 
            // DependLbl
            // 
            this.DependLbl.AutoSize = true;
            this.DependLbl.Location = new System.Drawing.Point(18, 49);
            this.DependLbl.Name = "DependLbl";
            this.DependLbl.Size = new System.Drawing.Size(71, 13);
            this.DependLbl.TabIndex = 72;
            this.DependLbl.Text = "Dependent(s)";
            // 
            // PosLbl
            // 
            this.PosLbl.AutoSize = true;
            this.PosLbl.Location = new System.Drawing.Point(19, 27);
            this.PosLbl.Name = "PosLbl";
            this.PosLbl.Size = new System.Drawing.Size(44, 13);
            this.PosLbl.TabIndex = 71;
            this.PosLbl.Text = "Position";
            // 
            // DependTxtBox
            // 
            this.DependTxtBox.Location = new System.Drawing.Point(118, 48);
            this.DependTxtBox.Name = "DependTxtBox";
            this.DependTxtBox.Size = new System.Drawing.Size(165, 20);
            this.DependTxtBox.TabIndex = 74;
            // 
            // PosTxtBox
            // 
            this.PosTxtBox.Location = new System.Drawing.Point(118, 24);
            this.PosTxtBox.Name = "PosTxtBox";
            this.PosTxtBox.Size = new System.Drawing.Size(165, 20);
            this.PosTxtBox.TabIndex = 73;
            // 
            // PicGrpBox
            // 
            this.PicGrpBox.Controls.Add(this.BrowseBtn);
            this.PicGrpBox.Controls.Add(this.EmpPicBox);
            this.PicGrpBox.Location = new System.Drawing.Point(1095, 239);
            this.PicGrpBox.Name = "PicGrpBox";
            this.PicGrpBox.Size = new System.Drawing.Size(243, 197);
            this.PicGrpBox.TabIndex = 12;
            this.PicGrpBox.TabStop = false;
            // 
            // BrowseBtn
            // 
            this.BrowseBtn.Location = new System.Drawing.Point(84, 166);
            this.BrowseBtn.Name = "BrowseBtn";
            this.BrowseBtn.Size = new System.Drawing.Size(75, 23);
            this.BrowseBtn.TabIndex = 1;
            this.BrowseBtn.Text = "Browse";
            this.BrowseBtn.UseVisualStyleBackColor = true;
            this.BrowseBtn.Click += new System.EventHandler(this.BrowseBtn_Click);
            // 
            // EmpPicBox
            // 
            this.EmpPicBox.Location = new System.Drawing.Point(6, 18);
            this.EmpPicBox.Name = "EmpPicBox";
            this.EmpPicBox.Size = new System.Drawing.Size(231, 144);
            this.EmpPicBox.TabIndex = 0;
            this.EmpPicBox.TabStop = false;
            // 
            // openFileDialog1
            // 
            this.openFileDialog1.FileName = "OpenFileDialog";
            // 
            // EmployeeReg
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.LightSeaGreen;
            this.ClientSize = new System.Drawing.Size(1350, 712);
            this.Controls.Add(this.PicGrpBox);
            this.Controls.Add(this.PositionGrpBox);
            this.Controls.Add(this.DataGridGrpBox);
            this.Controls.Add(this.CancelBtn);
            this.Controls.Add(this.DeleteBtn);
            this.Controls.Add(this.EditBtn);
            this.Controls.Add(this.ExitBtn);
            this.Controls.Add(this.NewBtn);
            this.Controls.Add(this.AddBtn);
            this.Controls.Add(this.EducationGrpBox2);
            this.Controls.Add(this.EducationGrpBox);
            this.Controls.Add(this.PersonInfoGrpBox2);
            this.Controls.Add(this.PersonInfoGrpBox);
            this.Name = "EmployeeReg";
            this.Text = "EmployeeReg";
            this.Load += new System.EventHandler(this.EmployeeReg_Load);
            this.PersonInfoGrpBox.ResumeLayout(false);
            this.PersonInfoGrpBox.PerformLayout();
            this.PersonInfoGrpBox2.ResumeLayout(false);
            this.PersonInfoGrpBox2.PerformLayout();
            this.EducationGrpBox.ResumeLayout(false);
            this.EducationGrpBox.PerformLayout();
            this.EducationGrpBox2.ResumeLayout(false);
            this.EducationGrpBox2.PerformLayout();
            this.DataGridGrpBox.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.EmpDataGrid)).EndInit();
            this.PositionGrpBox.ResumeLayout(false);
            this.PositionGrpBox.PerformLayout();
            this.PicGrpBox.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.EmpPicBox)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox PersonInfoGrpBox;
        private System.Windows.Forms.TextBox ZipTxtBox;
        private System.Windows.Forms.Label ZipLbl;
        private System.Windows.Forms.Label StateLbl;
        private System.Windows.Forms.Label CountryLbl;
        private System.Windows.Forms.Label CityLbl;
        private System.Windows.Forms.Label MuniLbl;
        private System.Windows.Forms.Label BarangayLbl;
        private System.Windows.Forms.Label StreetLbl;
        private System.Windows.Forms.Label PhaseLbl;
        private System.Windows.Forms.Label SubdiviLbl;
        private System.Windows.Forms.Label HouseNumLbl;
        private System.Windows.Forms.Label AddressLbl;
        private System.Windows.Forms.Label WeightLbl;
        private System.Windows.Forms.Label HeightLbl;
        private System.Windows.Forms.Label StatusLbl;
        private System.Windows.Forms.TextBox MuniTxtBox;
        private System.Windows.Forms.TextBox CityTxtBox;
        private System.Windows.Forms.TextBox CountryTxtBox;
        private System.Windows.Forms.Label YearsLbl;
        private System.Windows.Forms.TextBox StateTxtBox;
        private System.Windows.Forms.TextBox BarangayTxtBox;
        private System.Windows.Forms.TextBox StreetTxtBox;
        private System.Windows.Forms.TextBox PhaseTxtBox;
        private System.Windows.Forms.TextBox SubdiviTxtBox;
        private System.Windows.Forms.TextBox HouseNumTxtBox;
        private System.Windows.Forms.TextBox YearsTxtBox;
        private System.Windows.Forms.TextBox WeightTxtBox;
        private System.Windows.Forms.TextBox HeightTxtBox;
        private System.Windows.Forms.ComboBox StatusCmbBox;
        private System.Windows.Forms.TextBox PhilHealthTxtBox;
        private System.Windows.Forms.TextBox PagibigTxtBox;
        private System.Windows.Forms.TextBox TINTxtBox;
        private System.Windows.Forms.TextBox SSSTxtBox;
        private System.Windows.Forms.ComboBox GenderCmbBox;
        private System.Windows.Forms.ComboBox AgeCmbBox;
        private System.Windows.Forms.TextBox NumOfDepTxtBox;
        private System.Windows.Forms.TextBox SNameTxtBox;
        private System.Windows.Forms.TextBox MNameTxtBox;
        private System.Windows.Forms.TextBox FNameTxtBox;
        private System.Windows.Forms.Button SearchBtn;
        private System.Windows.Forms.TextBox EmpNumTxtBox;
        private System.Windows.Forms.Label PagibigLbl;
        private System.Windows.Forms.Label PhilHealthLbl;
        private System.Windows.Forms.Label GenderLbl;
        private System.Windows.Forms.Label SSSLbl;
        private System.Windows.Forms.Label TINLbl;
        private System.Windows.Forms.Label AgeLbl;
        private System.Windows.Forms.Label NumOfDepLbl;
        private System.Windows.Forms.Label SNameLbl;
        private System.Windows.Forms.Label MNameLbl;
        private System.Windows.Forms.Label FNameLbl;
        private System.Windows.Forms.Label EmpNumLbl;
        private System.Windows.Forms.GroupBox PersonInfoGrpBox2;
        private System.Windows.Forms.GroupBox EducationGrpBox;
        private System.Windows.Forms.TextBox PermZipTxtBox;
        private System.Windows.Forms.Label PermZipLbl;
        private System.Windows.Forms.Label PermStateLbl;
        private System.Windows.Forms.Label PermCountryLbl;
        private System.Windows.Forms.Label PermCityLbl;
        private System.Windows.Forms.Label PermMuniLbl;
        private System.Windows.Forms.Label PermBarangayLbl;
        private System.Windows.Forms.Label PermStreetLbl;
        private System.Windows.Forms.Label PermPhaseLbl;
        private System.Windows.Forms.Label PermSubdiviLbl;
        private System.Windows.Forms.Label PermHouseNumLbl;
        private System.Windows.Forms.TextBox PermMuniTxtBox;
        private System.Windows.Forms.TextBox PermCityTxtBox;
        private System.Windows.Forms.TextBox PermCountryTxtBox;
        private System.Windows.Forms.Label PermYearsLbl;
        private System.Windows.Forms.TextBox PermStateTxtBox;
        private System.Windows.Forms.TextBox PermBarangayTxtBox;
        private System.Windows.Forms.TextBox PermStreetTxtBox;
        private System.Windows.Forms.TextBox PermPhaseTxtBox;
        private System.Windows.Forms.TextBox PermSubdiviTxtBox;
        private System.Windows.Forms.TextBox PermHouseNumTxtBox;
        private System.Windows.Forms.TextBox PermYearsTxtBox;
        private System.Windows.Forms.Label ContactAddLbl;
        private System.Windows.Forms.Label ContactNumLbl;
        private System.Windows.Forms.Label ContactPerLbl;
        private System.Windows.Forms.Label EmailLbl;
        private System.Windows.Forms.Label Cell2Lbl;
        private System.Windows.Forms.Label Cell1Lbl;
        private System.Windows.Forms.Label TeleLbl;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.TextBox ContactAddTxtBox;
        private System.Windows.Forms.TextBox ContactNumTxtBox;
        private System.Windows.Forms.TextBox ContactPerTxtBox;
        private System.Windows.Forms.TextBox EmailTxtBox;
        private System.Windows.Forms.TextBox Cell2TxtBox;
        private System.Windows.Forms.TextBox Cell1TxtBox;
        private System.Windows.Forms.TextBox TeleTxtBox;
        private System.Windows.Forms.Label SecondAddLbl;
        private System.Windows.Forms.Label SecondSchoolLbl;
        private System.Windows.Forms.Label ElemAwardLbl;
        private System.Windows.Forms.Label ElemGradYearLbl;
        private System.Windows.Forms.Label ElemAddLbl;
        private System.Windows.Forms.Label ElemSchoolLbl;
        private System.Windows.Forms.TextBox SecondAddTxtBox;
        private System.Windows.Forms.TextBox ElemAwardTxtBox;
        private System.Windows.Forms.TextBox SecondSchoolTxtBox;
        private System.Windows.Forms.DateTimePicker ElemGradYearDateTime;
        private System.Windows.Forms.TextBox ElemAddTxtBox;
        private System.Windows.Forms.TextBox ElemSchoolTxtBox;
        private System.Windows.Forms.GroupBox EducationGrpBox2;
        private System.Windows.Forms.Label TertAwardLbl;
        private System.Windows.Forms.Label TertGradYearLbl;
        private System.Windows.Forms.TextBox TertAwardTxtBox;
        private System.Windows.Forms.DateTimePicker TertGradYearDateTime;
        private System.Windows.Forms.TextBox TertCourseTxtBox;
        private System.Windows.Forms.Label TertAddLbl;
        private System.Windows.Forms.Label TertSchoolLbl;
        private System.Windows.Forms.TextBox TertAddTxtBox;
        private System.Windows.Forms.TextBox TertSchoolTxtBox;
        private System.Windows.Forms.Label SecondAwardLbl;
        private System.Windows.Forms.Label SecondGradYearLbl;
        private System.Windows.Forms.TextBox SecondAwardTxtBox;
        private System.Windows.Forms.DateTimePicker SecondGradYearDateTime;
        private System.Windows.Forms.Label OthersLbl;
        private System.Windows.Forms.Label TertCourseLbl;
        private System.Windows.Forms.Label GradAwardLbl;
        private System.Windows.Forms.Label GradGradYearLbl;
        private System.Windows.Forms.TextBox OthersTxtBox;
        private System.Windows.Forms.DateTimePicker GradGradYearDateTime;
        private System.Windows.Forms.TextBox GradAwardTxtBox;
        private System.Windows.Forms.Label GradAddLbl;
        private System.Windows.Forms.Label GradDegLbl;
        private System.Windows.Forms.TextBox GradAddTxtBox;
        private System.Windows.Forms.TextBox GradDegTxtBox;
        private System.Windows.Forms.Label GradSchoolLbl;
        private System.Windows.Forms.TextBox GradSchoolTxtBox;
        private System.Windows.Forms.Button AddBtn;
        private System.Windows.Forms.Button NewBtn;
        private System.Windows.Forms.Button ExitBtn;
        private System.Windows.Forms.Button EditBtn;
        private System.Windows.Forms.Button DeleteBtn;
        private System.Windows.Forms.Button CancelBtn;
        private System.Windows.Forms.GroupBox DataGridGrpBox;
        private System.Windows.Forms.DataGridView EmpDataGrid;
        private System.Windows.Forms.GroupBox PositionGrpBox;
        private System.Windows.Forms.Label DeptLbl;
        private System.Windows.Forms.Label HireLbl;
        private System.Windows.Forms.TextBox DeptTxtBox;
        private System.Windows.Forms.DateTimePicker HireDateTime;
        private System.Windows.Forms.Label DependLbl;
        private System.Windows.Forms.Label PosLbl;
        private System.Windows.Forms.TextBox DependTxtBox;
        private System.Windows.Forms.TextBox PosTxtBox;
        private System.Windows.Forms.GroupBox PicGrpBox;
        private System.Windows.Forms.Button BrowseBtn;
        private System.Windows.Forms.PictureBox EmpPicBox;
        private System.Windows.Forms.TextBox PicPathTxtBox;
        private System.Windows.Forms.OpenFileDialog openFileDialog1;
    }
}